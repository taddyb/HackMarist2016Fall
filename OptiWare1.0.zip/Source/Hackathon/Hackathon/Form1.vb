﻿Imports System.IO
Imports NCalc
Imports System.Data
Imports System.Configuration
Imports System.DBNull
Public Class Form1
    Dim initialload As Boolean = True
    Dim qlist As String
    Private Sub Form1_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Dim appPath As String = Application.StartupPath()
        If My.Computer.FileSystem.FileExists(appPath + "/quotes1.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes1.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes2.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes2.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes3.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes3.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes4.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes4.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes5.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes5.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/tickers.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/tickers.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes12.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes12.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes13.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes13.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes14.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes14.csv")
        End If
        If My.Computer.FileSystem.FileExists(appPath + "/quotes15.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes15.csv")
        End If
    End Sub
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        ComboBox1.SelectedIndex = 0
        MetroTextBox1.Text = "lsp > 15.01 * 1.0;" _
            + vbNewLine + "peg < 0.5 * 1.2;" _
            + vbNewLine + "peg > 0.0 * 1.0;" _
            + vbNewLine + "lsp < 52wl * 1.2;"
    End Sub
    Public Sub GetTickers()
        Dim dllink As String
        Try
            If ComboBox1.SelectedItem.ToString = "NASDAQ" Then
                dllink = "http://www.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nasdaq&render=download"
            ElseIf ComboBox1.SelectedItem.ToString = "NYSE" Then
                dllink = "http://www.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=nyse&render=download"
            ElseIf ComboBox1.SelectedItem.ToString = "AMEX" Then
                dllink = "http://www.nasdaq.com/screening/companies-by-name.aspx?letter=0&exchange=amex&render=download"
            End If
        Catch ex As Exception
            MsgBox("Error -- please make sure you have selected a market in the box next to the refresh button")
            qlist = "-1"
            Exit Sub
        End Try
        Dim tickers As String
        Dim appPath As String = Application.StartupPath()
        If My.Computer.FileSystem.FileExists(appPath + "/tickers.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/tickers.csv")
            My.Computer.Network.DownloadFile(dllink, appPath + "/tickers.csv")
        Else
            My.Computer.Network.DownloadFile(dllink, appPath + "/tickers.csv")
        End If
        Dim sData() As String
        Dim arrSymbols, arrValue As New List(Of String)()

        Using sr As New StreamReader(appPath + "/tickers.csv")
            While Not sr.EndOfStream
                sData = sr.ReadLine().Split(","c)

                arrSymbols.Add(sData(0).Trim() + "+")
            End While
        End Using
        Dim n As Integer = 0
        Dim e As Integer = 0
        For Each elem As String In arrSymbols
            If n > -1 Then
                If e = 1 Then
                    tickers += arrSymbols(n) & "+"
                    e = 0
                Else
                    tickers += arrSymbols(n)
                End If
            End If
            n += 1
        Next
        tickers = tickers.Remove(0, 8)
        tickers = tickers.Remove(tickers.Length - 1)
        qlist = tickers
        Return
    End Sub
    Private Sub MetroButton1_Click(sender As System.Object, e As System.EventArgs) Handles MetroButton1.Click
        Dim qlist1 As String
        Dim qlist2 As String
        Dim qlist3 As String
        Dim qlist4 As String
        Dim qlist5 As String
        Dim qlist6 As String
        Dim qlist7 As String
        Dim qlist8 As String
        Dim qlist9 As String
        MetroProgressBar1.Value = 0
        Label1.Text = "Task: Collecting Data..."
        MetroProgressBar1.Value += 10
        MetroProgressBar1.Value += 10
        MetroProgressBar1.Value += 10
        GetTickers()
        If qlist = "-1" Then
            Label1.Text = "error!!"
            MetroProgressBar1.Value = 0
            Exit Sub
        End If
        MetroProgressBar1.Value += 20
        Dim appPath As String = Application.StartupPath()
        DataGridView1.Rows.Clear()
        Dim n = qlist.Length - 1
        qlist1 = qlist.Substring(0, n / 9)
        qlist2 = qlist.Substring(n / 9, n / 9)
        qlist3 = qlist.Substring(2 * (n / 9), n / 9)
        qlist4 = qlist.Substring(3 * (n / 9), n / 9)
        qlist5 = qlist.Substring(4 * (n / 9), n / 9)
        qlist6 = qlist.Substring(5 * (n / 9), n / 9)
        qlist7 = qlist.Substring(6 * (n / 9), n / 9)
        qlist8 = qlist.Substring(7 * (n / 9), n / 9)
        qlist9 = qlist.Substring(8 * (n / 9), n / 9)
        MetroProgressBar1.Value += 10
        If My.Computer.FileSystem.FileExists(appPath + "/quotes1.csv") Then
            My.Computer.FileSystem.DeleteFile(appPath + "/quotes1.csv")
            If My.Computer.FileSystem.FileExists(appPath + "/quotes2.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes2.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes3.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes3.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes4.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes4.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes5.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes5.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/tickers.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/tickers.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes6.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes6.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes12.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes12.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes13.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes13.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes14.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes14.csv")
            End If
            If My.Computer.FileSystem.FileExists(appPath + "/quotes15.csv") Then
                My.Computer.FileSystem.DeleteFile(appPath + "/quotes15.csv")
            End If
            'n = name
            'a = ask
            'b = bid
            'k = 52w h
            'j = 52w l
            'p = previous close
            'p2 = percent change
            't8 = 1yr target
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist1 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes1.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist2 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes2.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist3 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes3.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist4 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes4.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist5 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes5.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist6 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes12.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist7 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes13.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist8 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes14.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist9 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes15.csv")
        Else
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist1 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes1.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist2 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes2.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist3 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes3.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist4 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes4.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist5 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes5.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist6 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes12.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist7 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes13.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist8 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes14.csv")
            My.Computer.Network.DownloadFile("http://download.finance.yahoo.com/d/quotes.csv?s=" + qlist9 + "&f=sl1kjpt8p2r5vee9rs6m3m4y", appPath + "/quotes15.csv")
        End If
        MetroProgressBar1.Value += 10
        n = 0
        Dim sn As Integer = 0
        Dim n1 As Integer = 1
        MetroProgressBar1.Value += 10
        Do While n = 0
            Dim streamReader As IO.StreamReader = New IO.StreamReader(appPath + "/quotes" + n1.ToString + ".csv")
            'Reading CSV file content 

            While (streamReader.Peek() <> -1)
                Dim rowValue = streamReader.ReadLine()
                Dim cellvalue = rowValue.Split(","c)
                '0=symbol; 1=price; 2=52wh; 3=52wl; 4=plose; 5=target; 6=perch; 7=peg 
                Dim algo As String() = MetroTextBox1.Text.Split(";")
                Dim cnt As Integer = 0
                Dim acc As Integer = 0
                Do While cnt <= algo.Count - 1
                    Try
                        algo(cnt) = algo(cnt).TrimStart
                        Dim str As String() = algo(cnt).Split(" ")
                        Dim strint As Integer = 0
                        Do While strint < 5
                            If str(strint) = "lsp" Then
                                str(strint) = cellvalue(1)
                            ElseIf str(strint) = "52wh" Then
                                str(strint) = cellvalue(2)
                            ElseIf str(strint) = "52wl" Then
                                str(strint) = cellvalue(3)
                            ElseIf str(strint) = "pclose" Then
                                str(strint) = cellvalue(4)
                            ElseIf str(strint) = "target" Then
                                str(strint) = cellvalue(5)
                            ElseIf str(strint) = "perch" Then
                                str(strint) = cellvalue(6)
                            ElseIf str(strint) = "peg" Then
                                str(strint) = cellvalue(7)
                            ElseIf str(strint) = "vol" Then
                                str(strint) = cellvalue(8)
                            ElseIf str(strint) = "eps" Then
                                str(strint) = cellvalue(9)
                            ElseIf str(strint) = "epsnq" Then
                                str(strint) = cellvalue(10)
                            ElseIf str(strint) = "pe" Then
                                str(strint) = cellvalue(11)
                            ElseIf str(strint) = "rev" Then
                                str(strint) = cellvalue(12)
                            ElseIf str(strint) = "50dma" Then
                                str(strint) = cellvalue(13)
                            ElseIf str(strint) = "200dma" Then
                                str(strint) = cellvalue(14)
                            ElseIf str(strint) = "div" Then
                                str(strint) = cellvalue(15)
                            End If
                            strint += 1
                        Loop
                        Dim expr As Expression
                        'LESS THAN EXPRESSIONS BELOW~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        If algo(cnt).Contains("<") Then
                            If str(3) = "*" Then
                                expr = New Expression("[X] < ( [Z] * [Z2] )")
                            ElseIf str(3) = "/" Then
                                expr = New Expression("[X] < ( [Z] / [Z2] )")
                            ElseIf str(3) = "+" Then
                                expr = New Expression("[X] < ( [Z] + [Z2] )")
                            ElseIf str(3) = "-" Then
                                expr = New Expression("[X] < ( [Z] - [Z2] )")
                            End If
                            'expr should be something like lsp < 52wh * .8 hence x y z z1 z2
                            'MsgBox(str(0) & " < " & str(2) & str(3) & str(4).Substring(0, str(4).Length))
                            expr.Parameters("X") = Double.Parse(str(0))
                            expr.Parameters("Z") = Double.Parse(str(2))
                            expr.Parameters("Z2") = Double.Parse(str(4))
                            If expr.Evaluate Then
                                'MsgBox("true")
                                acc = 1
                            Else
                                'MsgBox("false")
                                acc = 0
                                cnt = algo.Count
                            End If
                            If cnt = algo.Count - 1 Then
                                DataGridView1.Rows.Add(cellvalue)
                            End If
                            'GREATER THAN EXPRESSIONS BELOW~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        ElseIf algo(cnt).Contains(">") Then
                            If str(3) = "*" Then
                                expr = New Expression("[X] > ( [Z] * [Z2] )")
                            ElseIf str(3) = "/" Then
                                expr = New Expression("[X] > ( [Z] / [Z2] )")
                            ElseIf str(3) = "+" Then
                                expr = New Expression("[X] > ( [Z] + [Z2] )")
                            ElseIf str(3) = "-" Then
                                expr = New Expression("[X] > ( [Z] - [Z2] )")
                            End If
                            'expr should be something like lsp < 52wh * .8 hence x y z z1 z2
                            'MsgBox(str(0) & " < " & str(2) & str(3) & str(4).Substring(0, str(4).Length))
                            expr.Parameters("X") = Double.Parse(str(0))
                            expr.Parameters("Z") = Double.Parse(str(2))
                            expr.Parameters("Z2") = Double.Parse(str(4))
                            If expr.Evaluate Then
                                'MsgBox("true")
                                acc = 1
                            Else
                                'MsgBox("false")
                                acc = 0
                                cnt = algo.Count
                            End If
                            If cnt = algo.Count - 1 Then
                                DataGridView1.Rows.Add(cellvalue)
                            End If
                            'EQUAL TO EXPRESSIONS BELOW~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
                        ElseIf algo(cnt).Contains("=") Then
                            If str(3) = "*" Then
                                expr = New Expression("[X] = ( [Z] * [Z2] )")
                            ElseIf str(3) = "/" Then
                                expr = New Expression("[X] = ( [Z] / [Z2] )")
                            ElseIf str(3) = "+" Then
                                expr = New Expression("[X] = ( [Z] + [Z2] )")
                            ElseIf str(3) = "-" Then
                                expr = New Expression("[X] = ( [Z] - [Z2] )")
                            End If
                            'expr should be something like lsp < 52wh * .8 hence x y z z1 z2
                            'MsgBox(str(0) & " < " & str(2) & str(3) & str(4).Substring(0, str(4).Length))
                            expr.Parameters("X") = Double.Parse(str(0))
                            expr.Parameters("Z") = Double.Parse(str(2))
                            expr.Parameters("Z2") = Double.Parse(str(4))
                            If expr.Evaluate Then
                                'MsgBox("true")
                                acc = 1
                            Else
                                'MsgBox("false")
                                acc = 0
                                cnt = algo.Count
                            End If
                            If cnt = algo.Count - 1 Then
                                DataGridView1.Rows.Add(cellvalue)
                            End If
                        End If

                    Catch ex As Exception
                        'MsgBox(ex.ToString)
                        cnt = algo.Count - 1
                    End Try
                    cnt += 1
                Loop
                sn += 1
                If acc = 1 Then
                    If cellvalue.Contains("N/A") Then
                    Else
                        DataGridView1.Rows.Add(cellvalue)
                    End If
                End If
            End While
            streamReader.Close()
            If n1 = 15 Then
                n = 1
            End If
            n1 += 1
            If n1 = 6 Then
                n1 = 12
            End If
        Loop
        MetroProgressBar1.Value += 10
        MetroProgressBar1.Value += 10
        Label1.Text = "Successful Execution!"
        'UPSIDE CHART
        Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Bar
        Chart1.Series(0).Points.Clear()
        Chart1.Series(0).IsVisibleInLegend = False
        For Count As Integer = 0 To DataGridView1.Rows.Count - 2
            If Count = 8 Then
                Count = DataGridView1.Rows.Count - 2
            End If
            Dim up As Double = 0
            Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
            Dim yh As Double = Double.Parse(DataGridView1.Item(2, Count).Value)
            up = ((yh - lsp) / lsp)
            Chart1.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
        Next
        'DOWNSIDE CHART
        Chart2.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Bar
        Chart2.Series(0).Points.Clear()
        Chart2.Series(0).IsVisibleInLegend = False
        For Count As Integer = 0 To DataGridView1.Rows.Count - 2
            If Count = 8 Then
                Count = DataGridView1.Rows.Count - 2
            End If
            Dim up As Double = 0
            Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
            Dim yl As Double = Double.Parse(DataGridView1.Item(3, Count).Value)
            up = ((yl - lsp) / lsp)
            Chart2.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
        Next
        Chart1.Series(0).Color = Color.Green
        Chart2.Series(0).Color = Color.Red
        MetroButton3.Enabled = True
    End Sub
    Public Sub UpdateChart()
        If DataGridView1.SelectedRows.Count = 0 Then
            Exit Sub
        End If
        'UPSIDE CHART
        Chart1.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Bar
        Chart1.Series(0).Points.Clear()
        Chart1.Series(0).IsVisibleInLegend = False
        If DataGridView1.SelectedRows().Count = 1 Then
            For Count As Integer = DataGridView1.SelectedRows(0).Index To DataGridView1.SelectedRows(DataGridView1.SelectedRows.Count - 1).Index
                If Count = 8 Then
                    Count = DataGridView1.Rows.Count - 2
                End If
                If DataGridView1.Item(1, Count).Value Is Nothing Then
                    Exit Sub
                End If
                Dim up As Double = 0
                Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
                Dim yh As Double = Double.Parse(DataGridView1.Item(2, Count).Value)
                up = ((yh - lsp) / lsp)
                Chart1.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
            Next
            'DOWNSIDE CHART
            Chart2.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Bar
            Chart2.Series(0).Points.Clear()
            Chart2.Series(0).IsVisibleInLegend = False
            For Count As Integer = DataGridView1.SelectedRows(0).Index To DataGridView1.SelectedRows(DataGridView1.SelectedRows.Count - 1).Index
                If Count = 8 Then
                    Count = DataGridView1.Rows.Count - 2
                End If
                If DataGridView1.Item(1, Count).Value Is Nothing Then
                    Exit Sub
                End If
                Dim up As Double = 0
                Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
                Dim yl As Double = Double.Parse(DataGridView1.Item(3, Count).Value)
                up = ((yl - lsp) / lsp)
                Chart2.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
            Next
            Chart1.Series(0).Color = Color.Green
            Chart2.Series(0).Color = Color.Red
            Return
        End If
        If DataGridView1.SelectedRows(0).Index < DataGridView1.SelectedRows(1).Index Then
            For Count As Integer = DataGridView1.SelectedRows(0).Index To DataGridView1.SelectedRows(DataGridView1.SelectedRows.Count - 1).Index
                If Count = 8 Then
                    Count = DataGridView1.Rows.Count - 2
                End If
                If DataGridView1.Item(1, Count).Value Is Nothing Then
                    Exit Sub
                End If
                Dim up As Double = 0
                Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
                Dim yh As Double = Double.Parse(DataGridView1.Item(2, Count).Value)
                up = ((yh - lsp) / lsp)
                Chart1.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
            Next
            'DOWNSIDE CHART
            Chart2.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Bar
            Chart2.Series(0).Points.Clear()
            Chart2.Series(0).IsVisibleInLegend = False
            For Count As Integer = DataGridView1.SelectedRows(0).Index To DataGridView1.SelectedRows(DataGridView1.SelectedRows.Count - 1).Index
                If Count = 8 Then
                    Count = DataGridView1.Rows.Count - 2
                End If
                If DataGridView1.Item(1, Count).Value Is Nothing Then
                    Exit Sub
                End If
                Dim up As Double = 0
                Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
                Dim yl As Double = Double.Parse(DataGridView1.Item(3, Count).Value)
                up = ((yl - lsp) / lsp)
                Chart2.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
            Next
            Chart1.Series(0).Color = Color.Green
            Chart2.Series(0).Color = Color.Red
            Return
        Else
            For Count As Integer = DataGridView1.SelectedRows(DataGridView1.SelectedRows.Count - 1).Index To DataGridView1.SelectedRows(0).Index
                If Count = 8 Then
                    Count = DataGridView1.Rows.Count - 2
                End If
                If DataGridView1.Item(1, Count).Value Is Nothing Then
                    Exit Sub
                End If
                If DataGridView1.SelectedRows(0).Index = DataGridView1.Rows.Count - 1 Then
                    If DataGridView1.SelectedRows(0).Index = Count + 1 Then
                        Exit Sub
                    End If
                End If
                Dim up As Double = 0
                Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
                Dim yh As Double = Double.Parse(DataGridView1.Item(2, Count).Value)
                up = ((yh - lsp) / lsp)
                Chart1.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
            Next
            'DOWNSIDE CHART
            Chart2.Series(0).ChartType = DataVisualization.Charting.SeriesChartType.Bar
            Chart2.Series(0).Points.Clear()
            Chart2.Series(0).IsVisibleInLegend = False
            For Count As Integer = DataGridView1.SelectedRows(DataGridView1.SelectedRows.Count - 1).Index To DataGridView1.SelectedRows(0).Index
                If Count = 8 Then
                    Count = DataGridView1.Rows.Count - 2
                End If
                If DataGridView1.Item(1, Count).Value Is Nothing Then
                    Exit Sub
                End If
                Dim up As Double = 0
                Dim lsp As Double = Double.Parse(DataGridView1.Item(1, Count).Value)
                Dim yl As Double = Double.Parse(DataGridView1.Item(3, Count).Value)
                up = ((yl - lsp) / lsp)
                Chart2.Series(0).Points.AddXY(DataGridView1.Item(0, Count).Value, up)
            Next
            Chart1.Series(0).Color = Color.Green
            Chart2.Series(0).Color = Color.Red
            Return
        End If
    End Sub
    Private Sub MetroButton2_Click(sender As System.Object, e As System.EventArgs) Handles MetroButton2.Click
        Dim file As String = Application.StartupPath & "/Release Notes.txt"
        If System.IO.File.Exists(file) = True Then
            Process.Start(file)
        Else
            MsgBox("ERROR: Release notes file is missing -- it is recommended that you redownload this application from the intended distribution.")
        End If
    End Sub
    Private Sub DataGridView1_SelectionChanged(sender As Object, e As System.EventArgs) Handles DataGridView1.SelectionChanged
        UpdateChart()
    End Sub

    Private Sub MetroButton3_Click(sender As System.Object, e As System.EventArgs) Handles MetroButton3.Click
        Label1.Text = "Task: Exporting to CSV"
        MetroProgressBar1.Value = 0
        MetroProgressBar1.Value += 20
        Dim apppath As String = Application.StartupPath
        'save records below
        Dim time As DateTime = DateTime.Now
        Dim format As String = "MMM-ddd-d-yyyy"
        Dim n As Integer = 1
        time = time.ToString.Replace("/", "-")
        While My.Computer.FileSystem.FileExists(apppath + "/records/" + time.ToString(format) + n.ToString + ".csv")
            n += 1
        End While
        If My.Computer.FileSystem.DirectoryExists(apppath + "/records/") Then
        Else
            My.Computer.FileSystem.CreateDirectory(apppath + "/records/")
        End If
        MetroProgressBar1.Value += 20
        Dim streamWriter As IO.StreamWriter = New IO.StreamWriter(apppath + "/records/" + time.ToString(format) + n.ToString + ".csv")
        Dim ticker As String = ""
        Dim price1 As Double = 0
        Dim high As Double = 0
        Dim low As Double = 0
        Dim close As Double = 0
        Dim target As Double = 0
        Dim change1 As String = ""
        Dim pchange As Double = 0
        Dim isneg As Integer = 0
        Dim winner As String()
        Dim pegrat As Double = 0
        Dim lprice As Double = 0
        Dim lhigh As Double = 0
        Dim llow As Double = 0
        Dim buyp As Double = 0
        Dim advice1 As String = 0
        Dim yl As String = 0
        Dim vol As Double = 0
        Dim eps As String = 0
        Dim epsest As Double = 0
        Dim yh As String = 0
        Dim perat As String = 0
        Dim rev As String = 0
        Dim fdma As String = 0
        Dim tdma As String = 0
        MetroProgressBar1.Value += 20
        streamWriter.WriteLine("Symbol,Price,52wh,52wl,Previous Close,Target")
        For Each row As DataGridViewRow In DataGridView1.Rows
            If Not row.IsNewRow Then
                isneg = 0
                'GET STOCK INFO
                pchange = Nothing
                pchange = New Double
                Try
                    ticker = row.Cells(0).Value.ToString
                    price1 = row.Cells(1).Value
                    yh = row.Cells(2).Value
                    yl = row.Cells(3).Value
                    close = row.Cells(4).Value
                    target = row.Cells(5).Value
                Catch ex As Exception
                End Try
                For Each c As Char In change1
                    If IsNumeric(c) Then
                        pchange = pchange & c
                    End If
                Next
            End If
            'adds to record below:
            streamWriter.WriteLine(ticker.ToString + "," + price1.ToString + "," + yh.ToString + "," + yl.ToString _
                                   + "," + close.ToString + "," + target.ToString)

            'CHECK FOR N/A DUPLICATES
            If Not row.IsNewRow Then
                Try
                    lprice = row.Cells(1).Value
                    lhigh = row.Cells(2).Value
                    llow = row.Cells(3).Value
                Catch ex As Exception
                End Try
            End If
            'RECYCLES TO NEXT SQ
        Next
        MetroProgressBar1.Value += 20
        MetroProgressBar1.Value += 20
        streamWriter.Close()
        Label1.Text = "Successfully Exported!"
        DataGridView1.Select()
    End Sub
End Class
